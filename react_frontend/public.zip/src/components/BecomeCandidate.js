import React, { Component } from "react";
import { Button, Form, Container } from "semantic-ui-react";
import Voter from "../deployed/voter";
import { connect } from "react-redux";

class CandidateForm extends Component {
  state = {
    hasPoliceCase: "",
    party: ""
  };

  static async getInitialProps(props) {
    const { aadhaar } = props.query;
    return {
      aadhaar
    };
  }

  componentDidMount() {
    if (!this.props.isLoggedIn) this.props.history.push("/");
  }

  becomeCandidate = async () => {
    console.log(this.props);
    const voter = await Voter(this.props.voterAddress);
    await voter.methods
      .becomeCandidate(this.state.hasPoliceCase, this.state.party)
      .send({
        from: this.props.admin,
        gas: 3000000
      });
    this.props.history.push(`/voter/details`);
  };

  render() {
    return (
      <Container>
        <link
          rel="stylesheet"
          href="//cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.css"
        />
        <Form onSubmit={this.becomeCandidate}>
          <Form.Field>
            <label>Criminal Records</label>
            <input
              placeholder="Criminal Records"
              value={this.state.hasPoliceCase}
              onChange={event =>
                this.setState({ hasPoliceCase: event.target.value })
              }
            />
            <label>Party Name</label>
            <input
              placeholder="Party Name"
              value={this.state.party}
              onChange={event => this.setState({ party: event.target.value })}
            />
          </Form.Field>
          <Button type="submit">Submit</Button>
        </Form>
      </Container>
    );
  }
}

// export default CandidateForm;

const mapStatetoProps = state => {
  const { isLoggedIn, aadhaar, voterAddress, admin } = state;
  return {
    isLoggedIn,
    aadhaar,
    voterAddress,
    admin
  };
};

export default connect(
  mapStatetoProps,
  null
)(CandidateForm);
