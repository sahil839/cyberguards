import web3 from "./web3";
import Ballot from "../build/contracts/Ballot.json";

const instance = new web3.eth.Contract(
  Ballot.abi,
  "0xC789F8329969eD20EDB1e96D3efA795942653377"
);

export default instance;
