import web3 from "./web3";
import VoterFactory from "../build/contracts/VoterFactory.json";

const instance = new web3.eth.Contract(
  VoterFactory.abi,
  "0x3c6757CF9A7378ec76DE4963829f41c9359263eB"
);

export default instance;
