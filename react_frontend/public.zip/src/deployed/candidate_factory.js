import web3 from "./web3";
import CandidateFactory from "../build/contracts/CandidateFactory.json";

const instance = new web3.eth.Contract(
  CandidateFactory.abi,
  "0x8A5bce60Ed6AdBdC3d19886AF180f4a23F8e958c"
);

export default instance;
