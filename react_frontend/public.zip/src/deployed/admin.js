import web3 from "./web3";
import Admin from "../build/contracts/Admin.json";

const instance = new web3.eth.Contract(
  Admin.abi,
  "0xb269571BB6c2997E085383B4fF945C7b967DD0eC"
);

export default instance;
